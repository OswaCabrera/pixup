package unam.diplomado.pixup.repository;

import unam.diplomado.pixup.domain.Domicilio;

public interface DomicilioRepository {

    Domicilio save(Domicilio domicilio);

}

