package unam.diplomado.notificacion.repository;

import unam.diplomado.notificacion.domain.Notificacion;

public interface NotificacionRepository {

    Notificacion save(Notificacion notificacion);

}
